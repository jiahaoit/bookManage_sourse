package org.action;
import java.util.List;
import org.vo.Tel;
import com.opensymphony.xwork2.ActionSupport;
public class ArrayTypeConverterAction extends ActionSupport{
	private Tel[] tel;           						//�������ʹ�ֵ
	public Tel[] getTel() {
		return tel;
	}
	public void setTel(Tel[] tel) {
		this.tel = tel;
	}	
	public String execute() throws Exception {
		return SUCCESS;
	}
}
