package org.converter;
import java.util.Map;
import org.apache.struts2.util.StrutsTypeConverter;
import org.vo.Tel;
public class ArrayTypeConverter extends StrutsTypeConverter{
	public Object convertFromString(Map arg0, String[] arg1, Class arg2) {
		Tel[] tel=new Tel[arg1.length];
		for(int i=0;i<arg1.length;i++){
			Tel t=new Tel();
			String []str=arg1[i].split("-");
			t.setSectionNo(str[0]);
			t.setTelNo(str[1]);
			tel[i]=t;
		}
		return tel;
	}
	public String convertToString(Map arg0, Object arg1) {
		Tel[] tel=(Tel[])arg1;
		String sReturn="[";
		for (int i=0;i<tel.length;i++){
			sReturn+="<"+tel[i].getSectionNo()+"-"+tel[i].getTelNo()+">";
		}
		sReturn+="]";
		return sReturn;
	}
}
