package org.action;
import org.vo.Tel;
import com.opensymphony.xwork2.ActionSupport;
public class MyTypeConverterAction extends ActionSupport{
	private Tel tel;
	public String execute() throws Exception {
		return SUCCESS;
	}
	public Tel getTel() {
		return tel;
	}
	public void setTel(Tel tel) {
		this.tel = tel;
	}
}
