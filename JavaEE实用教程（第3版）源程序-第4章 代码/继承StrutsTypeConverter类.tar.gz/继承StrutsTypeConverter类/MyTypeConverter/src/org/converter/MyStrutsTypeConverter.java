package org.converter;
import java.util.Map;
import org.apache.struts2.util.StrutsTypeConverter;
import org.vo.Tel;
public class MyStrutsTypeConverter extends StrutsTypeConverter{
	public Object convertFromString(Map arg0, String[] arg1, Class arg2) {
		Tel t=new Tel();
		String [] str=arg1[0].split("-");
		t.setSectionNo(str[0]);
		t.setTelNo(str[1]);
		return t;
	}
	public String convertToString(Map arg0, Object arg1) {
		Tel t=(Tel)arg1;
		return "["+t.getSectionNo()+"-"+t.getTelNo()+"]";
	}
}
