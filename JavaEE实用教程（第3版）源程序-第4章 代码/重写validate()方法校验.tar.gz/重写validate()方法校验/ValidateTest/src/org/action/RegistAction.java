package org.action;
import com.opensymphony.xwork2.ActionSupport;
public class RegistAction extends ActionSupport{
	private String username;		//����
	private String password;		//����
	private String repassword;		//ȷ������
	private int age;				//����
	//�������Ե�set��get����
	public String getUsername(){
		return this.username;
	}
	public void setUsername(String username){
		this.username = username;
	}
	
	public String getPassword(){
		return this.password;
	}
	public void setPassword(String password){
		this.password = password;
	}
	
	public String getRepassword(){
		return this.repassword;
	}
	public void setRepassword(String repassword){
		this.repassword = repassword;
	}
	
	public int getAge(){
		return this.age;
	}
	public void setAge(int age){
		this.age = age;
	}
	
	public String execute() throws Exception {
		return SUCCESS;
	}
	
	public void validate() {
		if(username.equals("")||username==null){
			addFieldError("username","usernameΪ��");
		}else if(password.equals("")|| password==null){
			addFieldError("password","passwordΪ��");
		}else if(repassword.equals("")||repassword==null){
			addFieldError("repassword","repasswordΪ��");
		}else if(!password.equals(repassword)){
			addFieldError("password","�����������벻ͬ");
		}else if(age<1||age>150){
			addFieldError("age","age������1��150֮��");
		}
	}
}
