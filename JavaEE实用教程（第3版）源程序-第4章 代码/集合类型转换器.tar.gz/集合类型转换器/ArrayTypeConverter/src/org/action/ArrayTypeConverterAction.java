package org.action;
import java.util.List;
import org.vo.Tel;
import com.opensymphony.xwork2.ActionSupport;
public class ArrayTypeConverterAction extends ActionSupport{
	private List<Tel> tel;       //Ӧ�÷���
	public List<Tel> getTel() {
		return tel;
	}
	public void setTel(List<Tel> tel) {
		this.tel = tel;
	}
	public String execute() throws Exception {
		return SUCCESS;
	}
}
