package org.converter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.struts2.util.StrutsTypeConverter;
import org.vo.Tel;
public class ListTypeConverter extends StrutsTypeConverter{
	public Object convertFromString(Map arg0, String[] arg1, Class arg2) {
		List<Tel> list=new ArrayList<Tel>();
		for(int i=0;i<arg1.length;i++){
			Tel t=new Tel();
			String []str=arg1[i].split("-");
			t.setSectionNo(str[0]);
			t.setTelNo(str[1]);
			list.add(t);        //�ѱ������������ݷָȻ���װ��Tel���뼯����
		}
		return list;
	}
	public String convertToString(Map arg0, Object arg1) {
		List<Tel> list=(List<Tel>) arg1;        //ת���ɼ�������
		String sReturn="[";
		for (int i=0;i<list.size();i++){
			sReturn+="<"+list.get(i).getSectionNo()+"-"+list.get(i).getTelNo()+">";
		}
		sReturn+="]";
		return sReturn;
	}
}
