package org.interceptor;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
public class MyInterceptor extends AbstractInterceptor{
	public String intercept(ActionInvocation arg0) throws Exception {
		System.out.println("����Actionǰִ��---->");
		String result=arg0.invoke();
		System.out.println("����Action��ִ��---->");
		return result;
	}
}
