package org.action;
import com.opensymphony.xwork2.ActionSupport;
public class LoginAction extends ActionSupport{
	public String execute() throws Exception {
		return SUCCESS;
	}
}
