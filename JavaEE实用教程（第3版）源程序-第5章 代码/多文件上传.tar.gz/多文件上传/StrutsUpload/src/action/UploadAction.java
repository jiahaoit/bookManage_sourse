package action;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import com.opensymphony.xwork2.ActionSupport;
public class UploadAction extends ActionSupport{
	private  List<File> upload;      	//�ϴ����ļ����ݣ������Ƕ������List����
	private List<String> uploadFileName;  //�ļ���
	public String execute() throws Exception {
		if(upload!=null){
			for (int i = 0; i < upload.size(); i++) {   //�������õ�ÿ���ļ������ǽ��ж�д����
				InputStream is=new FileInputStream(upload.get(i));
				OutputStream os=
						new FileOutputStream("d:\\upload\\"+getUploadFileName().get(i));
				byte buffer[]=new byte[1024];
				int count=0;
				while((count=is.read(buffer))>0){
					os.write(buffer,0,count);
				}
				os.close();
				is.close();
			}
		}
		return SUCCESS;
	}
	public List<File> getUpload() {
		return upload;
	}
	public void setUpload(List<File> upload) {
		this.upload = upload;
	}
	public List<String> getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(List<String> uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
}
