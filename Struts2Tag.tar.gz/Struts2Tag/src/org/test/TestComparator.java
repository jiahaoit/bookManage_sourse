package org.test;
import java.util.Comparator;
public class TestComparator implements Comparator{
	 public int compare(Object arg0, Object arg1) {
		 //�����ַ�����
		 return (arg0.toString().charAt(0)-arg1.toString().charAt(0));
	 }
}
