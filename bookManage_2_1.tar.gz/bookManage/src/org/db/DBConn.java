package org.db;
import java.sql.*;
public class DBConn{
	public static Connection conn;			//Connection对象（连接）
	private static String url = "jdbc:mysql://47.106.81.248:3306/mbook?useUnicode=true&characterEncoding=utf-8";
	private static String user = "ssh";
	private static String password = "ssh";
	//获取数据库连接
	public static Connection getConn(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			/**编写连接字符串，创建并获取连接*/
			conn = DriverManager.getConnection(url, user, password);
			return conn;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	//关闭连接
	public static void CloseConn(){
		try{
			conn.close();				//关闭连接
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}