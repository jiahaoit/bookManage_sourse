package org.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.model.*;
import org.dao.*;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("gb2312");		//设置请求编码
		//该类为项目与数据的接口（DAO接口），用于处理数据与数据库表的一些操作
		LoginDao loginDao = new LoginDao();
		Login l = loginDao.checkLogin(request.getParameter("name"), request.getParameter("password"));
		if(l!=null){								//如果登录成功
			HttpSession session = request.getSession();	//获得会话，用来保存当前登录用户的信息
			session.setAttribute("login", l);			//把获取的对象保存在 Session 中
            response.sendRedirect("main.jsp");			//验证成功跳转到欢迎主页 main.jsp
		}else{
			response.sendRedirect("error.jsp");			//验证失败跳转到错误处理页 error.jsp
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
