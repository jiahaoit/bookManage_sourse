package org.test;
import org.hibernate.*;
import org.vo.*;
import org.util.*;
public class Test {
	public static void main(String [] args){
		Session session = HibernateSessionFactory.getSession();
		Transaction ts = null;
		try{
			ts = session.beginTransaction();
			UserTable user = new UserTable();
			user.setUsername("jack");
			user.setPassword("123456");
			session.save(user);
			ts.commit();
		}catch(Exception e){
			if(ts!=null){
				ts.rollback();
			}
			e.printStackTrace();
		}finally{
			session.close();
		}
	}
}
