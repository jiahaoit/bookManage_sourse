package org.dao;
import org.vo.Login;
public interface LoginDao {
	//��ѯ��Ϣ
	public Login checkLogin(String name,String password);
}
