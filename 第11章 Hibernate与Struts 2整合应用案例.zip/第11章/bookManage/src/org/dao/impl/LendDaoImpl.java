package org.dao.impl;
import java.util.List;
import org.dao.LendDao;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.util.HibernateSessionFactory;
import org.vo.Book;
import org.vo.Lend;
import org.vo.Student;
public class LendDaoImpl implements LendDao{
	public List selectBook(String readerId,int pageNow,int pageSize) {
		Session session=null;
		Transaction tx=null;
		List list=null;
		try{
			session=HibernateSessionFactory.getSession();
			tx=session.beginTransaction();
			//��ѯָ�����е���Ϣ
			Query query=session.createQuery("select l.bookId,l.ISBN,b.bookName,b.publisher,b.price,l.ltime from Lend as l,Book as b where l.readerId=? and b.ISBN=l.ISBN");
			query.setParameter(0, readerId);
			//��ҳ
			//query.setFirstResult(pageSize*(pageNow-1));
			//query.setMaxResults(pageSize);
			list=query.list();
			tx.commit();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}finally{
			session.close();
		}
		return list;
	}
	public int selectBookSize(String readerId) {
		Session session=null;
		Transaction tx=null;
		int size=0;
		try{
			session=HibernateSessionFactory.getSession();
			tx=session.beginTransaction();
			Query query=session.createQuery("from Lend where readerId=?");
			query.setParameter(0, readerId);
			size=query.list().size();
			tx.commit();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}finally{
			session.close();
		}
		return size;
	}
	public void addLend(Lend lend,Book book,Student student) {
		Session session=null;
		Transaction tx=null;
		try{
			session=HibernateSessionFactory.getSession();
			tx=session.beginTransaction();
			session.save(lend);		 //���ӽ�����Ϣ
			session.update(book);       //�޸�ͼ����Ϣ��ͼ�еĿ����-1
			session.update(student);     //�޸�ѧ����Ϣ��ѧ���Ľ�����+1
			tx.commit();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}finally{
			session.close();
		}
	}
	public Lend selectByBookId(String bookId) {
		Session session=null;
		Transaction tx=null;
		Lend lend=null;
		try{
			session=HibernateSessionFactory.getSession();
			tx=session.beginTransaction();
			lend=(Lend)session.get(Lend.class, bookId);
			tx.commit();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}
		finally{ session.close();  }
		return lend;
	}
	public Lend selectByBookISBN(String ISBN) {
		Session session=null;
		Transaction tx=null;
		Lend lend=null;
		try{
			session=HibernateSessionFactory.getSession();
			tx=session.beginTransaction();
			Query query=session.createQuery("from Lend where ISBN=?");
			query.setParameter(0, ISBN);
			//query.setMaxResults(1);
			lend=(Lend) query.uniqueResult();
			tx.commit();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}
		finally{ session.close();  }
		return lend;
	}
}
