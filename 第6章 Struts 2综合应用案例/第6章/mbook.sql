-- MySQL dump 10.13  Distrib 5.6.41, for Linux (x86_64)
--
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	5.6.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mbook`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mbook` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `mbook`;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `ISBN` varchar(50) NOT NULL,
  `bookName` varchar(50) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `price` float(5,2) DEFAULT NULL,
  `cnum` int(20) DEFAULT NULL,
  `snum` int(20) DEFAULT NULL,
  `summary` varchar(500) DEFAULT NULL,
  `photo` varbinary(256) DEFAULT NULL,
  `publisher` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ISBN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES ('978-7-121-26623-2','SQL Server实用教程（第4版）','郑阿奇',49.00,10,10,'本书以Microsoft SQL Server 2014中文版为平台，系统地介绍SQL Server  2014基础、实验和综合应用等内容。',NULL,'电子工业出版社'),('978-7-121-30634-1','Visual C++实用教程（第5版）','郑阿奇',59.00,10,10,'本书仍然采用Visual C++ 6.0（中文版）平台，在第4版的基础上进行增减、修改和完善，同时兼顾C++等级考试的内容，从而进一步方便教和学。',NULL,'电子工业出版社'),('978-7-121-31698-2','Qt5开发及实例（第3版）','陆文周',99.00,10,10,'本书以Qt 5.8为平台，结合丰富的实例介绍Qt开发的基础知识。',NULL,'电子工业出版社'),('978-7-121-31883-2','Android实用教程','郑阿奇',45.00,10,10,'本书以Android Studio 2.x作为平台，系统介绍Android平台APP开发。',NULL,'电子工业出版社');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lend`
--

DROP TABLE IF EXISTS `lend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lend` (
  `bookId` int(10) NOT NULL,
  `readerId` varchar(50) DEFAULT NULL,
  `ISBN` varchar(50) DEFAULT NULL,
  `LTime` datetime DEFAULT NULL,
  PRIMARY KEY (`bookId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lend`
--

LOCK TABLES `lend` WRITE;
/*!40000 ALTER TABLE `lend` DISABLE KEYS */;
/*!40000 ALTER TABLE `lend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT 'False',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'a','a','True'),(2,'观海先生','a','True'),(3,'衣知世','a','True'),(4,'田松石','a','False'),(6,'ssh','ssh','False');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `readerId` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `sex` bit(1) DEFAULT NULL,
  `bron` datetime DEFAULT NULL,
  `spec` varchar(50) DEFAULT NULL,
  `num` int(20) DEFAULT '0',
  `photo` varbinary(256) DEFAULT NULL,
  PRIMARY KEY (`readerId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'温良恭','','2018-10-29 16:53:11','计算机科学与技术',0,NULL),(2,'谢知非','','2018-10-29 17:06:32','民族音乐学',0,NULL),(3,'季青临','','2018-10-29 17:06:33','古汉语文学专业',0,NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `test`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `test` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `test`;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES (1,'编号为：1'),(2,'编号为：2'),(3,'编号为：3'),(4,'编号为：4'),(5,'编号为：5'),(6,'编号为：6'),(7,'编号为：7'),(8,'编号为：8'),(9,'编号为：9'),(10,'编号为：10'),(11,'编号为：11'),(12,'编号为：12'),(13,'编号为：13'),(14,'编号为：14'),(15,'编号为：15'),(16,'编号为：16'),(17,'编号为：17'),(18,'编号为：18'),(19,'编号为：19'),(20,'编号为：20'),(21,'编号为：21'),(22,'编号为：22'),(23,'编号为：23'),(24,'编号为：24'),(25,'编号为：25'),(26,'编号为：26'),(27,'编号为：27'),(28,'编号为：28'),(29,'编号为：29'),(30,'编号为：30'),(31,'编号为：31'),(32,'编号为：32'),(33,'编号为：33'),(34,'编号为：34'),(35,'编号为：35'),(36,'编号为：36'),(37,'编号为：37'),(38,'编号为：38'),(39,'编号为：39'),(40,'编号为：40'),(41,'编号为：41'),(42,'编号为：42'),(43,'编号为：43'),(44,'编号为：44'),(45,'编号为：45'),(46,'编号为：46'),(47,'编号为：47'),(48,'编号为：48'),(49,'编号为：49'),(50,'编号为：50'),(51,'编号为：51'),(52,'编号为：52'),(53,'编号为：53'),(54,'编号为：54'),(55,'编号为：55'),(56,'编号为：56'),(57,'编号为：57'),(58,'编号为：58'),(59,'编号为：59'),(60,'编号为：60'),(61,'编号为：61'),(62,'编号为：62'),(63,'编号为：63'),(64,'编号为：64'),(65,'编号为：65'),(66,'编号为：66'),(67,'编号为：67'),(68,'编号为：68'),(69,'编号为：69'),(70,'编号为：70'),(71,'编号为：71'),(72,'编号为：72'),(73,'编号为：73'),(74,'编号为：74'),(75,'编号为：75'),(76,'编号为：76'),(77,'编号为：77'),(78,'编号为：78'),(79,'编号为：79'),(80,'编号为：80'),(81,'编号为：81'),(82,'编号为：82'),(83,'编号为：83'),(84,'编号为：84'),(85,'编号为：85'),(86,'编号为：86'),(87,'编号为：87'),(88,'编号为：88'),(89,'编号为：89'),(90,'编号为：90'),(91,'编号为：91'),(92,'编号为：92'),(93,'编号为：93'),(94,'编号为：94'),(95,'编号为：95'),(96,'编号为：96'),(97,'编号为：97'),(98,'编号为：98'),(99,'编号为：99');
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-29 17:46:00
