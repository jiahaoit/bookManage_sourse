package org.model;
import java.util.Date;
public class Lend {
	private String bookId;
	private String readerId;
	private String bookName;
	private String publisher;
	private float price;
	private String ISBN;
	private Date lTime;
	//�����������Ե�get��set����
	public String getBookId(){
		return this.bookId;
	}
	public void setBookId(String bookId){
		this.bookId = bookId;
	}
	
	public String getReaderId(){
		return this.readerId;
	}
	public void setReaderId(String readerId){
		this.readerId = readerId;
	}
	
	public String getBookName(){
		return this.bookName;
	}
	public void setBookName(String bookName){
		this.bookName = bookName;
	}
	
	public String getPublisher(){
		return this.publisher;
	}
	public void setPublisher(String publisher){
		this.publisher = publisher;
	}
	
	public float getPrice(){
		return this.price;
	}
	public void setPrice(float price){
		this.price = price;
	}
	
	public String getISBN(){
		return this.ISBN;
	}
	public void setISBN(String ISBN){
		this.ISBN = ISBN;
	}
	
	public Date getLTime(){
		return this.lTime;
	}
	public void setLTime(Date lTime){
		this.lTime = lTime;
	}
}
